package com.loan.hexagonal.domain.model;

public enum LoanStatus {
    PENDING,
    APPROVED,
    REJECTED
}
