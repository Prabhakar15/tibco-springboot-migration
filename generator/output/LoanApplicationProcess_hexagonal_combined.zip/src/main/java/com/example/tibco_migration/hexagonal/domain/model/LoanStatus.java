package com.example.tibco_migration.hexagonal.domain.model;

public enum LoanStatus {
    PENDING,
    APPROVED,
    REJECTED
}
