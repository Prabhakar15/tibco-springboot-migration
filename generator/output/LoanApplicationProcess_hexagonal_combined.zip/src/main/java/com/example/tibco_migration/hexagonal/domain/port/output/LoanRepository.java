package com.example.tibco_migration.hexagonal.domain.port.output;

import com.example.tibco_migration.hexagonal.domain.model.LoanApplication;
import java.util.Optional;

/**
 * Output port for loan persistence.
 * Infrastructure adapter will implement this.
 */
public interface LoanRepository {
    LoanApplication save(LoanApplication loan);
    Optional<LoanApplication> findById(String id);
}
