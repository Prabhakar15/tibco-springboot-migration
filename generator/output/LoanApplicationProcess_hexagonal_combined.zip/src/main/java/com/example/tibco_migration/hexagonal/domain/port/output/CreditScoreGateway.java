package com.example.tibco_migration.hexagonal.domain.port.output;

import com.example.tibco_migration.hexagonal.domain.model.ApplicantInfo;
import com.example.tibco_migration.hexagonal.domain.model.CreditScore;

/**
 * Output port for credit score checking.
 * HTTP client adapter will implement this.
 */
public interface CreditScoreGateway {
    CreditScore checkCredit(ApplicantInfo applicant);
}
