package com.example.tibco_migration.hexagonal.domain.port.output;

import com.example.tibco_migration.hexagonal.domain.model.LoanApplication;

/**
 * Output port for sending notifications.
 * JMS adapter will implement this.
 */
public interface NotificationGateway {
    void sendApplicationNotification(LoanApplication loan);
}
